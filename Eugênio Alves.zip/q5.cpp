#include <windows.h>
#include <GL/glut.h>
#include <iostream>
#include <math.h>

using namespace std;

//Eugênio Alves de Oliveira Filho.

float x_position = 4.0;
float y_position = 10.0;
GLfloat angle = 0;
int state = 1;
  
void objeto()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    gluOrtho2D(-10,10,-10,10);
    glPointSize(5);
    glBegin(GL_POINTS);
        glColor3f(1,0,0);
        glVertex3f(1,0,0);
        glVertex3f(2,0,0);
        glVertex3f(3,0,0);
        glVertex3f(4,0,0);
        glVertex3f(5,0,0);
        glVertex3f(0,0,0);
        glVertex3f(0,1,0);
        glVertex3f(0,2,0);
        glVertex3f(0,3,0);
        glVertex3f(0,4,0);
        glVertex3f(0,5,0);
    glEnd();
    glRotatef(90,0,0,1);
    glTranslatef(0,-5,0);
    glBegin(GL_TRIANGLES);
        glColor3f(3.0f, 3.0f,0);
        glVertex2f(3.0f, 1.0f);
        glVertex2f(1.0f, 3.0f);
        glVertex2f(3.0f, 3.00f);
    glEnd();
    glPopMatrix();
    glFlush();
    glutSwapBuffers();
}

void timer(int){
    glutPostRedisplay();
    glutTimerFunc(1000/60,timer,0);
    if(angle < 360){
        angle+=1;
    }
    else{
        angle = 0;
    }
}


void resize(int w, int h)
{
   glViewport(0, 0, (GLsizei)w, (GLsizei)h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluOrtho2D(0,640,480,0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}




int main(int argc, char *argv[])
{   
    glutInitWindowSize(600,600);
    glutCreateWindow("Questao 5");
    glutDisplayFunc(objeto);
    glutTimerFunc(0,timer,0);
    glutMainLoop();
    return 1;
}



//   g++ -o ex -Wall ex.cpp -mwindows glut32.lib -lopengl32 -lglu32